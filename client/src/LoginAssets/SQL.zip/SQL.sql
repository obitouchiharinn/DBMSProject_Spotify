CREATE DATABASE agriinvest;
use agriinvest;


CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('farmer', 'investor')),
    registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE land_listings (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    size DECIMAL(10, 2) NOT NULL,
    location VARCHAR(255) NOT NULL,
    soil_type VARCHAR(100) NOT NULL,
    infrastructure TEXT,
    proposed_crops TEXT,
    photos TEXT,
    MOBILE_NUMBER int,
    listed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
