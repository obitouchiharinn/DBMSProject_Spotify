// scripts.js

// Dummy data for land listings
const landListings = [];

// Farmer registration form submission
document.getElementById('farmer-register-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('farmer-name').value;
    const email = document.getElementById('farmer-email').value;
    const mobile = document.getElementById('farmer-mobile').value;
    const password = document.getElementById('farmer-password').value;

    if (validateRegistration(name, email, mobile, password)) {
        displayPopup('Welcome, Farmer!');
        document.getElementById('register').style.display = 'none';
        document.getElementById('list-land').style.display = 'block';
    } else {
        displayPopup('Wrong details. Please try again.');
    }
});

// Investor registration form submission
document.getElementById('investor-register-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const name = document.getElementById('investor-name').value;
    const email = document.getElementById('investor-email').value;
    const mobile = document.getElementById('investor-mobile').value;
    const password = document.getElementById('investor-password').value;

    if (validateRegistration(name, email, mobile, password)) {
        displayPopup('Welcome, Investor!');
        document.getElementById('register').style.display = 'none';
        document.getElementById('search-land').style.display = 'block';
    } else {
        displayPopup('Wrong details. Please try again.');
    }
});

// Validate registration details
function validateRegistration(name, email, mobile, password) {
    // Basic validation (can be expanded as needed)
    return name && email && mobile && password;
}

// List land form submission
document.getElementById('list-land-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const size = document.getElementById('size').value;
    const location = document.getElementById('location').value;
    const soilType = document.getElementById('soil-type').value;
    const infrastructure = document.getElementById('infrastructure').value;
    const proposedCrops = document.getElementById('proposed-crops').value;
    const photos = document.getElementById('photos').files;

    // Store the land listing
    const farmerMobile = document.getElementById('farmer-mobile').value;
    const listing = {
        size,
        location,
        soilType,
        infrastructure,
        proposedCrops,
        farmerMobile,
        photos: Array.from(photos).map(file => URL.createObjectURL(file))
    };

    landListings.push(listing);

    displayFarmerListings(farmerMobile);
    alert('Land listed successfully!');
});

// Display farmer's land listings
function displayFarmerListings(mobile) {
    const farmerListings = landListings.filter(listing => listing.farmerMobile === mobile);
    const listingsHtml = farmerListings.map(listing => `
        <div class="land-listing">
            <p><strong>Location:</strong> ${listing.location}</p>
            <p><strong>Size:</strong> ${listing.size} acres</p>
            <p><strong>Soil Type:</strong> ${listing.soilType}</p>
            <p><strong>Infrastructure:</strong> ${listing.infrastructure}</p>
            <p><strong>Proposed Crops:</strong> ${listing.proposedCrops}</p>
        </div>
    `).join('');

    document.getElementById('farmer-land-listings').innerHTML = listingsHtml;
}

// Search land form submission
document.getElementById('search-land-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const location = document.getElementById('search-location').value;
    const size = document.getElementById('search-size').value;
    const cropType = document.getElementById('search-crop-type').value;

    let resultsHtml = '<h3>Search Results:</h3>';
    const filteredListings = landListings.filter(listing => {
        return (!location || listing.location.includes(location)) &&
               (!size || listing.size == size) &&
               (!cropType || listing.proposedCrops.includes(cropType));
    });

    if (filteredListings.length > 0) {
        resultsHtml += filteredListings.map(listing => `
            <div class="land-listing">
                <p><strong>Location:</strong> ${listing.location}</p>
                <p><strong>Size:</strong> ${listing.size} acres</p>
                <p><strong>Soil Type:</strong> ${listing.soilType}</p>
                <p><strong>Infrastructure:</strong> ${listing.infrastructure}</p>
                <p><strong>Proposed Crops:</strong> ${listing.proposedCrops}</p>
                <p><strong>Contact:</strong> ${listing.farmerMobile}</p>
                <button onclick="viewDetails(${landListings.indexOf(listing)})">View Details</button>
            </div>
        `).join('');
    } else {
        resultsHtml += '<p>No results found.</p>';
    }

    document.getElementById('search-results').innerHTML = resultsHtml;
});

function viewDetails(index) {
    const listing = landListings[index];
    let detailsHtml = `
        <h3>Details for Land Listing</h3>
        <p><strong>Location:</strong> ${listing.location}</p>
        <p><strong>Size:</strong> ${listing.size} acres</p>
        <p><strong>Soil Type:</strong> ${listing.soilType}</p>
        <p><strong>Infrastructure:</strong> ${listing.infrastructure}</p>
        <p><strong>Proposed Crops:</strong> ${listing.proposedCrops}</p>
        <p><strong>Contact:</strong> ${listing.farmerMobile}</p>
        <h4>Photos:</h4>
        ${listing.photos.map(photo => `<img src="${photo}" alt="Land photo">`).join('')}
    `;

    document.getElementById('land-details-content').innerHTML = detailsHtml;
    document.getElementById('search-land').style.display = 'none';
    document.getElementById('land-details').style.display = 'block';
}

// Display popup
function displayPopup(message) {
    const popup = document.getElementById('popup');
    const popupMessage = document.getElementById('popup-message');
    popupMessage.textContent = message;
    popup.style.display = 'flex';
}

// Close popup
document.querySelector('.close-button').addEventListener('click', function() {
    document.getElementById('popup').style.display = 'none';
});
