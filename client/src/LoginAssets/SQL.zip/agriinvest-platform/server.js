const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mysql = require('mysql2');
const path = require('path'); // Import the path module

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Database connection
const pool = mysql.createPool({
    host: 'localhost',
    user: 'your_db_user',
    password: 'your_db_password',
    database: 'agriinvest',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Handle POST request for registering users
app.post('/register', (req, res) => {
    // Handle registration logic here
});

// Handle POST request for listing land
app.post('/list-land', (req, res) => {
    // Handle listing land logic here
});

// Handle POST request for searching land
app.post('/search-land', (req, res) => {
    // Handle searching land logic here
});

// Root route handler
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Other route handlers...

// Start server
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
